import { Injectable } from '@angular/core';
import { User } from './user_model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  user: User;
  editUser(user: User) {

    user.id = sessionStorage.getItem('id');
 user.name = sessionStorage.getItem("name");
    user.username = sessionStorage.getItem("username");
    user.email = sessionStorage.getItem("email");
    user.phone= sessionStorage.getItem("phone");
    user.street= sessionStorage.getItem("street");
    user.suite= sessionStorage.getItem("suite");
    user.city = sessionStorage.getItem("city");
    user.zipcode = sessionStorage.getItem("zipcode");
    user.companyName = sessionStorage.getItem("companyName");
    user.catchPhrase= sessionStorage.getItem("catchPhrase");
    user.bs = sessionStorage.getItem("bs");

  return user;
  }

  constructor() { }
}
