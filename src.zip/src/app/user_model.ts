export interface User {
id: string;
name: string;
username: string;
email: string;
phone: string;
street: string;
suite: string;
city: string;
zipcode: string;
companyName: string;
catchPhrase: string;
bs: string;
}