import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Key } from 'protractor';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  url="https://jsonplaceholder.typicode.com/users";
  users = [];
  id: string;
  user: [];

  constructor(private http: HttpClient, private router: Router,private userService: UserService) {
    this.http.get(this.url).toPromise().then(data => {

      console.log(data);

      for(let key in data)
        if (data.hasOwnProperty(key))
        this.users.push(data[key]);
    });
   }

  ngOnInit() {
  }

  viewUser(user) {
    console.log(user);

      sessionStorage.setItem('id',user.id)
      sessionStorage.setItem('name',user.name)
      sessionStorage.setItem('username',user.username)
      sessionStorage.setItem('email',user.email)
      sessionStorage.setItem('phone',user.phone)
      sessionStorage.setItem('street',user.address.street)
      sessionStorage.setItem('suite',user.address.suite)
      sessionStorage.setItem('zipcode',user.address.zipcode)
      sessionStorage.setItem('city',user.address.city)
      sessionStorage.setItem('companyName',user.company.name)
      sessionStorage.setItem('bs',user.company.bs)
      sessionStorage.setItem('catchPhrase',user.company.catchPhrase)

    this.id = user.id;
    this.router.navigateByUrl('user-list/user-details/'+this.id)
  }

}
