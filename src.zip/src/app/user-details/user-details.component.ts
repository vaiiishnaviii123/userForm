import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {

  id: number;
  name: string;
  username: string;
  email: string;
  phone: string;
  street: string;
  suite: string;
  city: string;
  zipcode: string;
  companyName: string;
  catchPhrase: string;
  bs: string;
  
  

  constructor(private router: Router) {
 

   }
  
  
  home(){
    this.router.navigateByUrl('/user-list')

  }
  ngOnInit() {
    this.name = sessionStorage.getItem("name");
    this.username = sessionStorage.getItem("username");
    this.email = sessionStorage.getItem("email");
    this.phone= sessionStorage.getItem("phone");
    this.street= sessionStorage.getItem("street");
    this.suite= sessionStorage.getItem("suite");
    this.city = sessionStorage.getItem("city");
    this.zipcode = sessionStorage.getItem("zipcode");
    this.companyName = sessionStorage.getItem("companyName");
    this.catchPhrase= sessionStorage.getItem("catchPhrase");
    this.bs = sessionStorage.getItem("bs");

    console.log(this.bs);
    console.log(this.name);
  }
  onSubmit()
  {
    this.router.navigateByUrl('/confirm')
  }

}
